#include <Arduino_RouterBridge.h>
#include <IRremote.hpp>

const int IR_RECEIVE_PIN = 8;

void printHex32(unsigned long value) {
  Monitor.print("0x");
  if (value < 0x10000000UL) {
    Monitor.print("0");
  }
  if (value < 0x01000000UL) {
    Monitor.print("0");
  }
  if (value < 0x00100000UL) {
    Monitor.print("0");
  }
  if (value < 0x00010000UL) {
    Monitor.print("0");
  }
  if (value < 0x00001000UL) {
    Monitor.print("0");
  }
  if (value < 0x00000100UL) {
    Monitor.print("0");
  }
  if (value < 0x00000010UL) {
    Monitor.print("0");
  }
  Monitor.print(value, HEX);
}

void printDecodedIrData() {
  Monitor.print("protocol=");
  Monitor.print(getProtocolString(IrReceiver.decodedIRData.protocol));

  Monitor.print(" address=");
  printHex32(IrReceiver.decodedIRData.address);

  Monitor.print(" command=");
  printHex32(IrReceiver.decodedIRData.command);

  Monitor.print(" raw=");
  printHex32(IrReceiver.decodedIRData.decodedRawData);

  Monitor.print(" bits=");
  Monitor.print(IrReceiver.decodedIRData.numberOfBits);

  if (IrReceiver.decodedIRData.flags & IRDATA_FLAGS_IS_REPEAT) {
    Monitor.print(" repeat=1");
  } else {
    Monitor.print(" repeat=0");
  }

  Monitor.println();
}

void setup() {
  Bridge.begin();
  Monitor.begin();

  IrReceiver.begin(IR_RECEIVE_PIN, ENABLE_LED_FEEDBACK);

  Monitor.println("IR mapper ready.");
  Monitor.print("Receiver pin: D");
  Monitor.println(IR_RECEIVE_PIN);
  Monitor.println("Press buttons on the IR remote to print decoded values.");
}

void loop() {
  if (IrReceiver.decode()) {
    printDecodedIrData();
    IrReceiver.resume();
  }

  delay(10);
}
